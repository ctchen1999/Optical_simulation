clc; clear; close all;
%%
field = Electirc_field(100, 100, 30, 30, 45);
field_calculation(field);
