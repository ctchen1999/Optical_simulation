clc; clear; close all;
%%
randomWalk(100,100,20,100,0.1,1)
% (sizeX,sizeY,numParticles,numIterations,stepTime,circleRadius)